const { Pool } = require('pg');

// Replace with your own PostgreSQL credentials
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'new_password',
    port: 5432,
});

module.exports = pool;