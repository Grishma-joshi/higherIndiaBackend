const express = require('express');
const pool = require('./database.js');
const app = express();
const port = 3000;

// Middleware to parse JSON requests
app.use(express.json());

// Create a new customer
app.post('/customers', async (req, res) => {
    const {
        customer_name, customer_po_no, customer_po_date, higher_invoice_no, invoice_date, delivery_date,
        project_signoff_date, product, oem, description, serial_no, part_code, qty, warranty, subscription,
        support, support_start_date, support_end_date, lic_certificate_no, lic_expiry_date, renewal_date,
        payment_status
    } = req.body;

    try {
        const result = await pool.query(
            `INSERT INTO customers (
                customer_name, customer_po_no, customer_po_date, higher_invoice_no, invoice_date, delivery_date,
                project_signoff_date, product, oem, description, serial_no, part_code, qty, warranty, subscription,
                support, support_start_date, support_end_date, lic_certificate_no, lic_expiry_date, renewal_date,
                payment_status
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21)
            RETURNING *`,
            [customer_name, customer_po_no, customer_po_date, higher_invoice_no, invoice_date, delivery_date,
             project_signoff_date, product, oem, description, serial_no, part_code, qty, warranty, subscription,
             support, support_start_date, support_end_date, lic_certificate_no, lic_expiry_date, renewal_date,
             payment_status]
        );
        res.status(201).json(result.rows[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get all customers
app.get('/customers', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM customers');
        res.status(200).json(result.rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get a single customer by ID
app.get('/customers/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const result = await pool.query('SELECT * FROM customers WHERE customer_id = $1', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Customer not found' });
        }
        res.status(200).json(result.rows[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update a customer by ID
app.put('/customers/:id', async (req, res) => {
    const { id } = req.params;
    const {
        customer_name, customer_po_no, customer_po_date, higher_invoice_no, invoice_date, delivery_date,
        project_signoff_date, product, oem, description, serial_no, part_code, qty, warranty, subscription,
        support, support_start_date, support_end_date, lic_certificate_no, lic_expiry_date, renewal_date,
        payment_status
    } = req.body;

    try {
        const result = await pool.query(
            `UPDATE customers SET
                customer_name = $1, customer_po_no = $2, customer_po_date = $3, higher_invoice_no = $4,
                invoice_date = $5, delivery_date = $6, project_signoff_date = $7, product = $8, oem = $9,
                description = $10, serial_no = $11, part_code = $12, qty = $13, warranty = $14,
                subscription = $15, support = $16, support_start_date = $17, support_end_date = $18,
                lic_certificate_no = $19, lic_expiry_date = $20, renewal_date = $21, payment_status = $22
            WHERE customer_id = $23
            RETURNING *`,
            [customer_name, customer_po_no, customer_po_date, higher_invoice_no, invoice_date, delivery_date,
             project_signoff_date, product, oem, description, serial_no, part_code, qty, warranty, subscription,
             support, support_start_date, support_end_date, lic_certificate_no, lic_expiry_date, renewal_date,
             payment_status, id]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Customer not found' });
        }
        res.status(200).json(result.rows[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Delete a customer by ID
app.delete('/customers/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const result = await pool.query('DELETE FROM customers WHERE customer_id = $1 RETURNING *', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Customer not found' });
        }
        res.status(200).json(result.rows[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
